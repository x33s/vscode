
/**
 * VueRouter类，整个vuerouter的核心类
 * @constructor
 * @param {object} routes - 配置的routes的配置文件
 */
export default class VueRouter {
    constructor(routes) {
        this.routes = routes;
        this.history = new History();
        this.path = window.location.hash;
    }

    init(vm) {
        this.history.listen(path => {
            this.path = path;
            vm.$forceUpdate();
        });
    }
};

/**
 * History类，表示对于真正浏览器的histroy的操作与监听
 */
class History {
    /**
     * 监听路由变化
     * @param {function} cb 当history发生变化时，执行的回调
     */
    listen(cb) {
        window.addEventListener('hashchange', function () {
            cb && cb(window.location.hash);
        });
    }
}

VueRouter.install = function (Vue) {

    Vue.mixin({

        beforeCreate() {
            if (this.$options.router) {
                this.$options.router.init(this);
            }
        }

    });

    Vue.component('router-view', {

        functional: true,

        render(createElement, { props, children, parent, data }) {

            const path = parent.$options.router.path;

            // 从配置文件中找到对应的组件
            const matchRoute = parent.$options.router.routes.routes
                    .filter(route => {
                        return route.path.replace(/^\//, '') === path.replace(/^\#\//, '');
                    })[0];
            const component = matchRoute ? matchRoute.component : '';

            return createElement(
                component
            );
        }
    });
};
