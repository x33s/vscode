// import VueRouter from 'vue-router';
import Vue from 'vue';
import VueRouter from './vue-fake-router-multiple';

// 1. 安装插件
Vue.use(VueRouter);

const rootComp = {
	template: '<div>欢迎来到王者峡谷</div>'
};

const aliComp = {
	template: `<div>
			<router-view></router-view>
		</div>`
};

const aliSkinComp = {
	template: '<div><img src="./images/ali.jpg" /></div>'
};


const aliSkin2Comp = {
	template: '<div><img src="./images/ali-skin2.jpg" /></div>'
};

const aliSkin1Comp = {
	template: '<div><img src="./images/ali-skin1.jpg" /></div>'
};

const dunshanComp = {
	template: '<div><img src="./images/dunshan.jpg" /></div>'
};

// 2. 定义路由
const routes = [
	{
		path: '/',
		component: rootComp
	},
	{
		path: '/ali',
		component: aliComp,
		children: [
			{
				path: '/',
				component: aliSkinComp
			},
			{
				path: 'skin1',
				component: aliSkin1Comp
			},
			{
				path: 'skin2',
				component: aliSkin2Comp
			}
		]
	},
	{
		path: '/dunshan',
		component: dunshanComp
	}
];

// 3. new一个router的实例
var router = new VueRouter({ routes });

// 4. 把router实例放入vue根元素中作为属性
const App = new Vue({

	router,

	template: `<div id="newapp">
		<router-view></router-view>
	</div>`
});

App.$mount('#app');