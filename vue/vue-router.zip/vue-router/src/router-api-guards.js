import VueRouter from 'vue-router';
import Vue from 'vue';

// 1. 安装插件
Vue.use(VueRouter);

const rootComp = {
	template: '<div>欢迎来到王者峡谷</div>'
};

const aliComp = {
	template: `<div>
			<router-view></router-view>
		</div>`
};

const aliSkinComp = {
	template: '<div><img src="./images/ali.jpg" /></div>'
};


const aliSkin2Comp = {
	template: '<div><img src="./images/ali-skin2.jpg" /></div>'
};

const aliSkin1Comp = {
	template: '<div><img src="./images/ali-skin1.jpg" /></div>'
};

const dunshanComp = {
	template: '<div><img src="./images/dunshan.jpg" /></div>'
};

// 2. 定义路由
const routes = [
	{
		path: '/',
		component: rootComp
	},
	{
		path: '/ali',
		component: aliComp,
		children: [
			{
				path: '/',
				component: aliSkinComp
			},
			{
				path: 'skin1',
				component: aliSkin1Comp
			},
			{
				path: 'skin2',
				component: aliSkin2Comp
			}
		]
	},
	{
		path: '/dunshan',
		component: dunshanComp
	}
];

// 3. new一个router的实例
var router = new VueRouter({ routes });

router.beforeEach((to, from, next) => {
	console.log('执行了我：', to, from);
	next();
})

// 4. 把router实例放入vue根元素中作为属性
const App = new Vue({

	router,

	template: `<div id="newapp">
		<a v-on:click="skip('/dunshan')">盾山</a>
		<a v-on:click="skip('/ali')">公孙离</a>
		<a v-on:click="skip('/ali/skin1')">公孙离皮肤1</a>
		<a v-on:click="skip('/ali/skin2')">公孙离皮肤2</a>
		<router-view></router-view>
	</div>`,

	methods: {
		skip: function (path) {
			this.$router.push(path);
		}
	}
});

App.$mount('#app');