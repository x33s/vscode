
/**
 * VueRouter类，整个vuerouter的核心类
 * @constructor
 * @param {object} routes - 配置的routes的配置文件
 */
export default class VueRouter {

    constructor({routes}) {
        this.routes = routes;
        this.history = new History();
        this.path = window.location.hash;
    }

    init(vm) {
        this.history.listen(path => {
            this.path = path;
            vm.$forceUpdate();
        });
    }
};

/**
 * History类，表示对于真正浏览器的histroy的操作与监听
 */
class History {
    /**
     * 监听路由变化
     * @param {function} cb 当history发生变化时，执行的回调
     */
    listen(cb) {
        window.addEventListener('hashchange', function () {
            cb && cb(window.location.hash);
        });
    }
}

/**
 * matcher函数，从routes中，找出path对应的所有组件，组成一个数组
 * @param {array} routes - 路由的配置
 * @param {string} path - 需要匹配的路径
 * @param {number} index - 当前查找到了第几层
 */
function matcher(routes, path, index) {
    let paths = path.split('/');
    for (let routeName in routes) {
        let route = routes[routeName];
        if (
            route.path.replace(/^\//, '') === paths[index].replace(/^\//, '')
        ) {
            if (route.children) {
                let components = matcher(route.children, path, index + 1);
                if (components === false) {
                    continue;
                }
                return [route.component, ...components];
            }
            else if (index >= paths.length - 1) {
                return [route.component];
            }
            else {
                continue;
            }
        }
    };
    return false;
}

/**
 * getMatchedComponent函数，用于匹配某一个path在routes中对应的组件
 * @param {array} routes - 路由的配置
 * @param {string} path - 需要匹配的路径
 * @param {number} depth - 想用第几层的组件
 */
function getMatchedComponent(routes, path, depth) {

    let matchRes = matcher(routes, path, 0);
    if (!matchRes) {
        return null;
    }

    return {
        ...matchRes[depth - 1]
    };
}


VueRouter.install = function (Vue) {

    Vue.mixin({

        beforeCreate() {
            if (this.$options.router) {
                this.$options.router.init(this);
                this.routerRoot = this;
            }
            else {
                this.routerRoot = (this.$parent && this.$parent.routerRoot) || this;
            }
        }

    });

    Vue.component('router-view', {

        functional: true,

        render(createElement, { props, children, parent, data }) {
            // 标记自己是一个view-router
            parent.isRouterView = true;
            
            let depth = 1;

            let searchedParent = parent;

            // 向上查找routerRoot，并在查找的过程中记录，中间有几层view-router
            while (searchedParent && searchedParent.routerRoot !== searchedParent) {
                if (searchedParent.isRouterView) {
                    depth++;
                }
                searchedParent = searchedParent.$parent;
            }

            // 利用找到的routerRoot，获取上面的router，
            const router = searchedParent.$options.router;
            const path = router.path.replace(/^#\//, '');

            // 获取当前应匹配的组件
            const matchedComponent = getMatchedComponent(router.routes, path, depth);

            return createElement(
                matchedComponent
            );
        }
    });
};
