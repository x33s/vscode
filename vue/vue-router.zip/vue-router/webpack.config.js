const path = require('path');

module.exports = {

	entry: {
		// index: __dirname + '/src/index.js'
		index: __dirname + '/src/router-children.js'
		// index: __dirname + '/src/router-switch.js'
		// index: __dirname + '/src/router-params.js'
		// index: __dirname + '/src/router-api-guards.js'
	},

	output: {
		path: __dirname + '/dist',
		filename: 'index.js'
	},

	module: {
		rules: [
	        {
	            test: /\.js$/,
	            use: {
	                loader: 'babel-loader',
	                options: {
	                    presets: [['env']]
	                }
	            },
	            exclude: path.resolve(__dirname, '/node_modules'),
            	include: path.resolve(__dirname, '/src'),
	        },
	    ]
	},

	resolve: {
		alias: {
			vue: 'vue/dist/vue.common.dev.js',
		}
	},

	devServer: {
	    port: 3000,
	    progress: true,
	    contentBase: './'
	}
};
