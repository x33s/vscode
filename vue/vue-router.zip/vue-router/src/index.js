// import VueRouter from 'vue-router';
import VueRouter from './vue-fake-router';
import Vue from 'vue';

// 1. 安装插件
Vue.use(VueRouter);

const rootComp = {
	template: '<div>欢迎来到王者峡谷</div>'
};

const aliComp = {
	template: '<div><img src="./images/ali.jpg" /></div>'
};

const dunshanComp = {
	template: '<div><img src="./images/dunshan.jpg" /></div>'
};

// 2. 定义路由
const routes = [
	{
		path: '/',
		component: rootComp
	},
	{
		path: '/ali',
		component: aliComp
	},
	{
		path: '/dunshan',
		component: dunshanComp
	}
];

// 3. new一个router的实例
var router = new VueRouter({ routes });

// 4. 把router实例放入vue根元素中作为属性
const App = new Vue({

	router,

	template: `<div id="newapp">
		<router-view></router-view>
	</div>`
});

App.$mount('#app');